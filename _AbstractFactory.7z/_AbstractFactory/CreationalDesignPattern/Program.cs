﻿using AbstractFactory.ProductInterface;
using FactoryMethod;
using FactoryMethod.Factory;
using FactoryMethod.FactoryInterface;
using FactoryMethod.ProductInterface;
using System;

namespace CreationalDesignPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            // Simple factory
            //IMobile mobile = MobileFactory.CreateMobile(BrandType.Samsung);
            //mobile.GetMobile();

            // factory method
            //IMobileFactory mobileFactory = new XiaomiFactory();
            //IMobile mobile = mobileFactory.GetMobile(ModelType.RedmiPro);

            //mobile.GetMobile();

            // Abstract factory
            IMobileFactory mobileFactory = new SamsungFactory();
            mobileFactory.GetMobile(ModelType.Galaxy).GetMobile();
            mobileFactory.GetSignalStrenght(ModelType.Galaxy).ShowSignalStrength();

            Console.ReadKey();
        }
    }
}
