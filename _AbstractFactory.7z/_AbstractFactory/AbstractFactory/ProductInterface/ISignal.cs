﻿namespace AbstractFactory
{
    public interface ISignal
    {
        void ShowSignalStrength();
    }
}
