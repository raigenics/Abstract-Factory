﻿namespace AbstractFactory
{
    public interface IMobile
    {
        void GetMobile();
    }
}
