﻿using System;

namespace AbstractFactory.ProductB
{
    public class XiaomiRedmiProSignal : ISignal
    {
        public void ShowSignalStrength()
        {
            throw new NotImplementedException();
        }
    }
}
