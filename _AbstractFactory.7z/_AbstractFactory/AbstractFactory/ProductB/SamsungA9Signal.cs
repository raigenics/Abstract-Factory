﻿using System;

namespace AbstractFactory.ProductB
{
    public class SamsungA9Signal : ISignal
    {
        public void ShowSignalStrength()
        {
            throw new NotImplementedException();
        }
    }
}
