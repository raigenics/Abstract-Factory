﻿using System;

namespace AbstractFactory.ProductB
{
    public class XiaomiRedmi6Signal : ISignal
    {
        public void ShowSignalStrength()
        {
            throw new NotImplementedException();
        }
    }
}
